# Zee

Android WebView app for: https://hussenyioh-art.github.io/App-Doctor-/

## Build
Push to GitHub — Actions will auto-build the APK in ~5 minutes.
Check the **Actions** tab → download artifact **app-debug**.
